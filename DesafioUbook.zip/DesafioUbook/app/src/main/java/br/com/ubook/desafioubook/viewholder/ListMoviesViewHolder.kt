package br.com.ubook.desafioubook.viewholder

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.row_movie.view.*

class ListMoviesViewHolder(val context: Context, view: View): RecyclerView.ViewHolder(view) {

    var image: ImageView = view.poster
    var title: TextView = view.title
    var rating: TextView = view.rating
    val date: TextView = view.date

}