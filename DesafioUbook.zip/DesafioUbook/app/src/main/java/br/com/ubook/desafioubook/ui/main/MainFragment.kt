package br.com.ubook.desafioubook.ui.main

import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import br.com.ubook.desafioubook.BuildConfig
import br.com.ubook.desafioubook.R
import br.com.ubook.desafioubook.adaper.ListMoviesAdapter
import br.com.ubook.desafioubook.domain.Movie
import br.com.ubook.desafioubook.domain.ResultMoviesList
import br.com.ubook.desafioubook.mvp.interfaces.APIMovie
import br.com.ubook.desafioubook.mvp.presenter.PresenterListMovies
import br.com.ubook.desafioubook.network.ListMoviesManager
import kotlinx.android.synthetic.main.main_fragment.*

class MainFragment : Fragment(), APIMovie.ViewListMovieImpl {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var adapter: ListMoviesAdapter
    private lateinit var viewModel: MainViewModel
    private lateinit var presenterListMovies: PresenterListMovies
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.main_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requestListMoviesStart()
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(MainViewModel::class.java)

    }

    override fun requestListMoviesStart() {
        presenterListMovies = PresenterListMovies()
        presenterListMovies.bind(this, ListMoviesManager("top_rated"))
        presenterListMovies.requestListMovies()
    }

    override fun requestListMoviesSucess(listMovies: ResultMoviesList) {
        adapter = ListMoviesAdapter(context!!, listMovies.results)
        recycler_list_movies.adapter = adapter
        val mLayoutManager = LinearLayoutManager(context)
        recycler_list_movies.layoutManager = mLayoutManager
        adapter.notifyDataSetChanged()
    }

    override fun requestListMoviesError() {

    }
}
