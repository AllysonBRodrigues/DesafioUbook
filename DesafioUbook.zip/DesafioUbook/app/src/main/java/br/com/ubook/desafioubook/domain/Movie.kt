package br.com.ubook.desafioubook.domain

data class Movie(val title: String,
                 val poster_path: String,
                 val overview: String,
                 val vote_average: Float,
                 val original_language: String,
                 val release_date: String
                 )