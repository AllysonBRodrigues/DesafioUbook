package br.com.ubook.desafioubook.domain

class ResultMoviesList(val page: Int,
                       val total_result: Int,
                       val results: List<Movie>)