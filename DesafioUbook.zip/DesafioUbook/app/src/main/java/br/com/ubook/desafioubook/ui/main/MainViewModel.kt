package br.com.ubook.desafioubook.ui.main

import android.arch.lifecycle.ViewModel

class MainViewModel : ViewModel() {

}
