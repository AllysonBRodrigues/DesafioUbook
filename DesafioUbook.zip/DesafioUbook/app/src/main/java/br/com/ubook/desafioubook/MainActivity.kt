package br.com.ubook.desafioubook

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import br.com.ubook.desafioubook.ui.main.MainFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)
    }

}
