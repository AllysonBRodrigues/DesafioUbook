package br.com.ubook.desafioubook.adaper

import android.content.Context
import android.graphics.ColorSpace
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.Navigation
import br.com.ubook.desafioubook.R

import br.com.ubook.desafioubook.domain.Movie
import br.com.ubook.desafioubook.viewholder.ListMoviesViewHolder
import com.squareup.picasso.Picasso
import java.text.FieldPosition

class ListMoviesAdapter(val context: Context, val list: List<Movie>) :  RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(context)
        val view: View = inflater.inflate(R.layout.row_movie, parent, false)
        return ListMoviesViewHolder(context, view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        var view = (viewHolder as ListMoviesViewHolder)

        Picasso.get()
                .load(list[position].poster_path)
                .fit()
                .into(view.image)

        view.date.text = list[position].release_date
        view.title.text = list[position].title
        view.rating.text = "${list[position].vote_average}"
        view.itemView.setOnClickListener {
           Navigation.findNavController(it).navigate(R.id.action_mainFragment_to_dateilFragment)
        }

    }
}